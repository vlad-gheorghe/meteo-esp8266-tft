# NodeMCU-ESP12E-pinouts
Pinout poster for NodeMCU based on ESP-12E module

![NodeMCU-pinout image](https://1.bp.blogspot.com/-1JGckA3HPC8/W-0kY8ONQRI/AAAAAAAABxs/a5UV15pLQssM_uO6id8S28Muq86inTspQCLcBGAs/s1600/ESP-12E-pinout-preview.png)

Special Thanks to [ACROBOTIC industries](https://acrobotic.com/) for original poster design.

###### Detailed pins description
https://arduino-esp8266.readthedocs.io/en/latest/reference.html


###### Changelog
15/11/18 - Changed ESP-12 onboard LED pin. 
